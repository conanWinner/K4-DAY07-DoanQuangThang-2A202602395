---
doc_id: "shopee-co-inspection-program"
title: "Chương trình Shopee Đồng Kiểm"
source_url: "https://help.shopee.vn/portal/4/article/124982"
retrieved_at: "2026-09-20"
document_version: "not-stated"
audience: "buyer"
category: "shipping-policy"
language: "vi"
strategy: "recursive"
chunk_index: 14
char_count: 223
---
Mã giảm giá (Voucher) có thể Được/Không được hoàn lại tùy theo quy định hoàn mã giảm giá của Shopee dành cho đơn Hủy hoặc đơn Trả hàng/ Hoàn tiền khi bạn từ chối nhận hàng hoặc yêu cầu Trả hàng/ Hoàn tiền sau khi đồng kiểm.
